﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using eBatch.BusinessEntities.Models;
using eBatch.Common;
using System.Data;
using eBatch.BusinessEntities.Enums;

namespace eBatch.ResourceAccess
{
    public class SuppliersRal
    {
        /// <summary>
        /// To get Suppliers
        /// </summary>
        /// <returns>List of Suppliers</returns>
        public List<Supplier> GetSuppliers()
        {
            return Db.Fetch<Supplier>(SPEnum.spGetSuppliers.ToString());
        }

        /// <summary>
        /// To Save Supplier details
        /// </summary>
        /// <param name="Supplier">Supplier.</param>
        public void SaveSuppliers(Supplier supplier)
        {
            var dynParams = new DynamicParameters();
            dynParams.Add("@SupplierId", supplier.id);
            dynParams.Add("@approval_number", supplier.approval_number);
            dynParams.Add("@email", supplier.email );
            dynParams.Add("@DifficultyLevel", supplier.DifficultyLevel);
            dynParams.Add("@Status", supplier.Status);
            dynParams.Add("@suppliername", supplier.suppliername);
            dynParams.Add("@invoice_type", supplier.invoice_type);
            CommandDefinition cmd = new CommandDefinition(SPEnum.spSaveSuppliers.ToString(), dynParams, commandType: CommandType.StoredProcedure);
            Db.Save(cmd);
        }
    }
}
