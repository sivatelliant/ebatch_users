﻿using eBatch.BusinessLogic.Bpl;
using eBatch.Theme.Purple;
using eBatchApp.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL = eBatch.BusinessEntities.Models;


namespace eBatchApp.Admin
{
    public partial class AdminHome : eForm
    {
        public AdminHome()
        {
            InitializeComponent();
            dgvUsers.AutoGenerateColumns = false;
        }

        private void AdminHome_Load(object sender, EventArgs e)
        {
            tbAdminModule.SelectedTab = tbUser;
            tbAdminModule.Location = new Point(0, 0);
            LoadUsers();
        }

        public void LoadUsers()
        {
            dgvUsers.DataSource = new UsersBpl().GetUsers();

            DataGridViewButtonColumn EditColumn = new DataGridViewButtonColumn();
            EditColumn.Text = "Edit";
            EditColumn.Name = "Edit";
            // EditColumn.DataPropertyName = "Edit";
            EditColumn.UseColumnTextForButtonValue = true;
            dgvUsers.Columns.Add(EditColumn);
            DataGridViewButtonColumn DelColumn = new DataGridViewButtonColumn();
            DelColumn.Text = "Delete";
            DelColumn.Name = "Delete";
            // DelColumn.DataPropertyName = "Delete";
            DelColumn.UseColumnTextForButtonValue = true;
            dgvUsers.Columns.Add(DelColumn);
        }



        private void btnAddUser_Click(object sender, EventArgs e)
        {
            // int id = (int)dgvUsers.CurrentRow.Cells[0].Value;
            using (AddUser aduser = new AddUser())
            {
                if (aduser.ShowDialog() != DialogResult.Cancel)
                {
                    LoadUsers();
                }
            }
        }

        private void tbSupplier_Click(object sender, EventArgs e)
        {
            LoadSuppliers();
        }

        private void LoadSuppliers()
        {
            // dgvSuppliers.DataSource = new UsersBpl().GetUsers();
        }

        private void tbSupplier_FontChanged(object sender, EventArgs e)
        {

        }

        private void tbSupplier_Enter(object sender, EventArgs e)
        {
            LoadSuppliers();
        }

        private void tbRoleMapping_Enter(object sender, EventArgs e)
        {
            LoadRoleMapping();
        }

        private void LoadRoleMapping()
        {
            cbUsers.DataSource = new UsersBpl().GetUsers();
            cbUsers.ValueMember = "id";
            cbUsers.DisplayMember = "username";

            dgvUserRoleMapping.DataSource = Utility.LoadCode(eBatch.BusinessEntities.Enums.CodeEnum.Module);
        }

        private void dgvUserRoleMapping_Enter(object sender, EventArgs e)
        {

        }


        private void dgvUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int userid = (int)dgvUsers.CurrentRow.Cells[0].Value;
            int difflevel = (int)dgvUsers.CurrentRow.Cells[3].Value;
            if (e.ColumnIndex == 5)  //edit record
            {
                int selectedRowIndex = dgvUsers.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dgvUsers.Rows[selectedRowIndex];
                AddUser objUser = new AddUser();
                objUser.AddUserID(userid);
                objUser.txtUserName.Text = (string)dgvUsers.CurrentRow.Cells[1].Value;
                objUser.cbRole.Text = (string)dgvUsers.CurrentRow.Cells[2].Value;
                objUser.cbDifficultyLevel.SelectedValue = difflevel;
                
                objUser.ShowDialog();
            }
            if (e.ColumnIndex == 6) //delete
            {
                Utility.Validate();
                BL.User user = new BL.User()
                {
                    id = userid,
                    Status = false  //update only the status column
                };

                new UsersBpl().DeleteUsers(user);
                this.Close();
            }
        }
    }
}
