﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eBatch.Theme.Purple
{
    public class eFormPopup : System.Windows.Forms.Form
    {
        public eFormPopup()
        {
            Text = "Dialog";
        }
    }
}
