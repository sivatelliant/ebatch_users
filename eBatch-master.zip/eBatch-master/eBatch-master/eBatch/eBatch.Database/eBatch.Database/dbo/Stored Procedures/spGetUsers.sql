﻿create procedure spGetUsers
as 
begin
select * from tblUsers
end