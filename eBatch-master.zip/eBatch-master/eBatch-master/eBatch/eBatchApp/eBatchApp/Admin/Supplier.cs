﻿using eBatch.Theme.Purple;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace eBatchApp.Admin
{
    public partial class Supplier : eForm
    {
        public Supplier()
        {
            InitializeComponent();
        }
    }
}
