﻿namespace eBatch.BusinessEntities.Models
{
    public class Role
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }

    }
}