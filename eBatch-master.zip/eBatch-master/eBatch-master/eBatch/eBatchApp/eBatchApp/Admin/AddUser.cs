﻿using eBatch.BusinessEntities.Enums;
using eBatch.BusinessLogic.Bpl;
using eBatch.Theme.Purple;
using System;
using eBatchApp.Common;
using BL = eBatch.BusinessEntities.Models;
using System.Windows.Forms;
using System.Data;

namespace eBatchApp.Admin
{
    public partial class AddUser : eFormPopup
    {

        public AddUser()
        {
            InitializeComponent();
        }

        public void AddUserID(int uID)
        {
            usrgrdid = uID;
        }
        public int usrgrdid = 0;
        private void AddUser_Load(object sender, EventArgs e)
        {
            Utility.LoadCodeToCB(cbDifficultyLevel, CodeEnum.DifficultyLevel);
            Utility.LoadCodeToCB(cbRole, CodeEnum.UserRole);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("chumma save");
        }


        private void btnSave_Click(object sender, EventArgs e)
        {

            Utility.Validate();
            BL.User user = new BL.User()
            {
                id = usrgrdid,
                username = txtUserName.Text,
                userRole = new BL.Role() { RoleId = cbRole.SelectedValue.toInt() },
                DifficultyLevel = cbDifficultyLevel.SelectedValue.toInt(),
                Status = checkBox1.Checked
            };

            new UsersBpl().SaveUsers(user);
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
