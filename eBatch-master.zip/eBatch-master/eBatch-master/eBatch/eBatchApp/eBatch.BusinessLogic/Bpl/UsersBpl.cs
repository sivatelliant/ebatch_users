﻿using eBatch.BusinessEntities.Models;
using eBatch.ResourceAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eBatch.BusinessLogic.Bpl
{
    public class UsersBpl
    {
        public List<User> GetUsers()
        {
            return new UsersRal().GetUsers();
        }

        //public List<User> GetUsersID()
        //{
        //    return new UsersRal().GetUsersID();
        //}

        public void SaveUsers(User user)
        {
            new UsersRal().SaveUsers(user);
        }

        public void DeleteUsers(User user)
        {
            new UsersRal().DeleteUsers(user);
        }
    }

 
}
